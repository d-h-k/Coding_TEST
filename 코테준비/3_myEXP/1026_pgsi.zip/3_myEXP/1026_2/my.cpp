#include <cstring>
#include <vector>
#include <stack>
#include <iostream>

using namespace std;

vector<int> solution(int n) {
    vector<int> answer;
    stack<int> st;
    int temp=0;
    
    //answer.push_back(0);
    for(int i=1 ; i<=n ; i++) {
        for(int j=1; j<=answer.size() ; j++) {
            st.push(answer[j]);
        }
        
        temp = st.top();
        if(temp==0) {
            temp=1;
        }
        else {
            temp = 0;
        }
        answer.push_back(temp);
        st.pop();
        
    }
         
    return answer;
}

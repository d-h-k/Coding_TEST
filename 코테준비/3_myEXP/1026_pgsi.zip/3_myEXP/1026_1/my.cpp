#include <cstdio>
using namespace std;
int get_gcdf(int a,int b);
int get_loss(int srsa, int srsb);

//sol func
long long solution(int w,int h)
{
    int gcd=0;
    int wa=0,ha=0;
    int loss=0;
    //puts("hewllo");
	long long answer = 1;
	gcd = get_gcdf(w,h);
    wa = w / gcd;
    ha = h/ gcd; 
    loss = get_loss(wa,ha);
    
    //answer = (long long)loss*(long long)wa*(long long)ha;
    answer = (long long)loss*(long long)gcd*(long long)gcd;
    printf("%lld",answer);
    return answer;
}


//gcd
int get_gcdf(int a, int b)
{
	int c;
	while (b != 0)
	{
		c = a % b;
		a = b;
		b = c;
	}
	return a;
}

int get_loss(int srsa, int srsb) //�Ķ���͵��� ���μ��Դϴ�(�ִ������� 1�� ����)
{   
    int ret = 0;
    ret = srsa+srsb-1;
    return ret;
}
